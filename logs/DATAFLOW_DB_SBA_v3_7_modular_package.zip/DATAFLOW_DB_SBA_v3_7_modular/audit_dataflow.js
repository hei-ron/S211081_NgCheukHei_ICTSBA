const fs=require('fs');
const html=fs.readFileSync('./index.html','utf8');
const core=fs.readFileSync('./js/dataflow-core.js','utf8');
const m=core.match(/const DATA=(\{.*?\});\nconst addressFixes/s);
if(!m) throw new Error('DATA literal not found in core JS');
const D=JSON.parse(m[1]); let failures=0;
function check(name,ok,detail=''){console.log(`${ok?'PASS':'FAIL'} | ${name}${detail?' | '+detail:''}`);if(!ok)failures++;}
const pks={USER:'user_id',ADDRESS:'address_id',SHOP:'shop_id',PRODUCT:'product_id',ORDERS:'order_id',ORDER_PRODUCTS:'op_id',PICKUP_POINT:'pt_id',PT_HUB:'hub_id'};
for(const [t,k] of Object.entries(pks)){const ids=D[t].map(r=>r[k]);check(`${t} primary keys unique`,new Set(ids).size===ids.length,`${ids.length} records`)}
const refs=[['ADDRESS','user_id','USER','user_id'],['ADDRESS','shop_id','SHOP','shop_id'],['ADDRESS','hub_id','PT_HUB','hub_id'],['PRODUCT','shop_id','SHOP','shop_id'],['ORDERS','user_id','USER','user_id'],['ORDER_PRODUCTS','order_id','ORDERS','order_id'],['ORDER_PRODUCTS','product_id','PRODUCT','product_id'],['ORDER_PRODUCTS','origin_address_id','ADDRESS','address_id'],['ORDER_PRODUCTS','dest_address_id','ADDRESS','address_id'],['PICKUP_POINT','address_id','ADDRESS','address_id'],['PT_HUB','address_id','ADDRESS','address_id']];
for(const [t,f,p,k] of refs){const bad=D[t].filter(r=>r[f]!=null&&r[f]!==''&&!D[p].some(x=>x[k]===r[f]));check(`${t}.${f} foreign keys valid`,bad.length===0,bad.length?`${bad.length} invalid`:'')}
const mismatches=[];for(const o of D.ORDERS){const sum=D.ORDER_PRODUCTS.filter(x=>x.order_id===o.order_id).reduce((s,x)=>s+Number(x.sale_price)*Number(x.quantity),0);if(Math.abs(sum-Number(o.total))>.011)mismatches.push(o.order_id)}check('order total equals sum of detail lines',mismatches.length===0,mismatches.join(', '));
const validStatuses=['待付款','待發貨','已攬收','待轉運','運輸中','二次派送中','待取件','已簽收'];const badStatus=D.ORDER_PRODUCTS.filter(x=>!validStatuses.includes(x.status));check('ORDER_PRODUCTS statuses supported',badStatus.length===0,badStatus.map(x=>x.op_id).join(', '));
for(const t of ['PRODUCT'])check(`${t} numeric ranges valid`,D[t].every(x=>x.price>0&&x.stock>=0&&Number.isInteger(x.stock)&&x.volume_unit>0));
for(const t of ['PICKUP_POINT','PT_HUB'])check(`${t} capacity ranges valid`,D[t].every(x=>x.max_capa>0&&x.current_occ>=0&&x.current_occ<=x.max_capa));
console.log(`\n${failures?`FAILED: ${failures} check(s)`:'ALL CHECKS PASSED'}`);process.exitCode=failures?1:0;
